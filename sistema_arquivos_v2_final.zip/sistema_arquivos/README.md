# Sistema de arquivos baseado em i-nodes

Simulador de sistema de arquivos em Python, com disco virtual de 128 MiB, blocos, i-nodes, diretórios, links simbólicos e persistência. A **versão 2** torna o sistema **multiusuário**: login com senha, uma área pessoal para cada usuário, dono e permissões de leitura e escrita em todo arquivo, e os comandos `chmod` e `chown`.

> Trabalho acadêmico desenvolvido em duas etapas. A primeira construiu o sistema de arquivos; esta atualização acrescenta a camada de segurança sobre ele. A versão anterior continua disponível no [histórico do repositório](https://github.com/yuriserra1/sistema_arquivos/tree/35372a3f25092aa5b5497bcc41e7dd4c220f3a39).

![Sessão com três usuários no mesmo disco](assets/terminal-seguranca.svg)

## O problema

Na versão 1, todo i-node já tinha os campos de dono e permissões, mas eles não tinham efeito: o dono era sempre `usuario`, a permissão era sempre `rwxr-x` e qualquer pessoa lia, alterava ou apagava qualquer arquivo.

O objetivo da versão 2 foi fazer esses campos valerem: vários usuários no mesmo disco, cada um com sua área, permissões aplicadas em todos os comandos e senhas que não ficam expostas nem para quem lê o disco.

## O que mudou na versão 2

- **Login obrigatório.** Nenhum comando é aceito antes de usuário e senha válidos. Na primeira execução, o programa pede a senha do administrador (`root`).
- **Usuários com área própria.** O root cria contas com `useradd`. Cada conta ganha `/home/nome`, que só o dono acessa.
- **Dono e permissões que valem.** Todo arquivo pertence a quem o criou e tem dois pares de permissão, leitura e escrita: um para o dono e outro para os demais usuários.
- **`chmod` e `chown`.** O dono ou o root alteram as permissões, em dois formatos (`rwr-` ou `64`). Só o root troca o dono.
- **Senhas protegidas.** Ficam em `/etc/shadow` como hash PBKDF2-SHA256 com sal. Usuário comum não lê, copia, altera nem apaga esse arquivo.
- **Comandos novos.** `useradd`, `passwd`, `whoami`, `logout` e `ls -l`, que mostra tipo, permissões, dono e tamanho.

![Como uma permissão é decidida](assets/permissoes.svg)

## Arquitetura

![Diagrama da arquitetura](assets/arquitetura.svg)

A ideia central: **uma única função decide o acesso, e todo comando a consulta antes de agir.** `pode()` recebe um i-node e a ação pedida (`r` ou `w`). Se o usuário é o root, permite. Se é o dono, usa as duas primeiras letras da permissão; senão, as duas últimas. `exigir()` chama `pode()` e interrompe o comando com `PermissionError` quando a resposta é não.

| Operação | Exige |
|---|---|
| Ler um arquivo (`cat`, origem do `cp`) | `r` no arquivo |
| Alterar um arquivo (`echo`, destino do `cp`, `touch` em arquivo existente) | `w` no arquivo |
| Listar ou entrar num diretório (`ls`, `cd`) | `r` no diretório |
| Atravessar um caminho (`/a/b/c`) | `r` em cada diretório do caminho |
| Criar ou remover entradas (`touch`, `mkdir`, `rm`, `rmdir`, `ln`) | `w` no diretório pai |
| Mover ou renomear (`mv`) | `w` nos dois diretórios pais |
| `chmod` | ser o dono ou o root |
| `chown`, `useradd`, `passwd` de outro usuário | ser o root |

## Decisões de projeto

**O arquivo de senhas é protegido pelo próprio sistema.** `/etc/shadow` é um arquivo comum do disco virtual, com dono root e permissão `rw--`, dentro de `/etc`, onde só o root escreve. Não existe uma regra especial para ele: as mesmas verificações que protegem qualquer arquivo o protegem. Até um link simbólico para `/etc/shadow` esbarra na permissão do alvo, porque o caminho é resolvido de novo a cada uso.

**Quem lê o shadow é o sistema, não o usuário.** As verificações estão nos comandos digitados. As funções internas de login e senha leem o arquivo diretamente, como o programa de login e o kernel fazem no Linux.

**A senha nunca é gravada.** Cada senha recebe um sal de 16 bytes do gerador seguro do sistema operacional (`os.urandom`) e passa por PBKDF2-HMAC-SHA256 com 100.000 iterações (`hashlib`). No login, o hash é recalculado com o sal guardado e comparado em tempo constante (`hmac.compare_digest`). Usuário inexistente e senha errada recebem a mesma mensagem, para não revelar quem tem conta.

**Criar e apagar exigem escrita no diretório pai.** A entrada `nome → i-node` fica no diretório que contém o arquivo; é ele que muda. É a regra do Unix, e por isso escrever num arquivo não dá direito de apagá-lo.

**Sem o bit `x`.** O trabalho pede leitura e escrita. Num diretório, `r` vale para listar e para atravessar.

**Só o root troca o dono.** Como no Unix: se qualquer dono pudesse, um usuário conseguiria atribuir arquivos a outra pessoa.

**Uma recusa não deixa rastro.** A transação herdada da versão 1 copia i-nodes e mapas antes de cada comando. Quando uma permissão falha, a cópia é restaurada e nada é gravado. Os testes comparam o SHA-256 da imagem antes e depois da operação recusada.

**Imagens da versão 1 continuam abrindo.** Ao carregar uma imagem antiga, `rwxr-x` vira `rwr-`, o dono passa a ser o root e são criados `/etc`, `/home` e `/root`.

## Funcionando

![Testes automáticos](assets/terminal-testes.svg)

O roteiro de demonstração cria dois usuários e tenta, um por um, os acessos que devem ser barrados: ler, copiar, alterar e apagar `/etc/shadow`, invadir `/home`, usar `chown` sem ser root, ler e alterar arquivos privados de outro usuário. Ele produz **13 recusas, todas esperadas**, e termina com uma troca de senha.

## Números

- **40 testes automáticos**, 8 dedicados à segurança: senhas, arquivo de senhas, permissões, `chmod`, `chown`, `passwd`, login e migração de imagens antigas.
- **13 recusas esperadas** no roteiro de demonstração, que um dos testes executa de ponta a ponta.
- **100.000 iterações** de PBKDF2 e sal de 16 bytes por senha.
- Disco de **128 MiB**, blocos de **2.048 bytes**, até **8.192 i-nodes**.
- **Nenhuma dependência externa**: só a biblioteca padrão do Python.

## Executar

Requer Python 3.10 ou superior.

```bash
python main.py
```

Na primeira execução, defina a senha do `root` e faça login. A senha não aparece enquanto é digitada.

```text
root@myfs> useradd ana
root@myfs> logout
login: ana
ana@myfs> echo "meu segredo" > segredo.txt
ana@myfs> chmod rw-- segredo.txt
ana@myfs> ls -l
```

Demonstração automática, numa pasta sem `filesystem.img`:

```bash
python main.py < roteiro_demonstracao.txt
```

Testes:

```bash
python -m unittest -v testes
```

O manual completo, com todos os comandos e a organização do disco, está em [`docs/MANUAL.md`](docs/MANUAL.md). A descrição dos testes está em [`docs/VALIDACAO.md`](docs/VALIDACAO.md).

## Arquivos

| Arquivo | Conteúdo |
|---|---|
| `main.py` | Sistema de arquivos, segurança e terminal interativo |
| `testes.py` | 40 testes automatizados com imagens temporárias |
| `roteiro_demonstracao.txt` | Sequência de comandos da demonstração |
| `docs/MANUAL.md` | Instruções de uso e funcionamento |
| `docs/VALIDACAO.md` | Testes realizados e resultados |

## Limites conhecidos

- Não há grupos de usuários nem remoção de contas.
- Não há limite de tentativas de login; o PBKDF2 torna cada tentativa lenta, mas não bloqueia.
- A proteção vale dentro do disco virtual. O arquivo `filesystem.img` no computador depende das permissões do sistema operacional, e ele guarda só os hashes das senhas.
- Os metadados usam `pickle`; abra apenas imagens de procedência conhecida.

## Tecnologias

Python 3 · hashlib (PBKDF2-HMAC-SHA256) · hmac · os.urandom · getpass · pickle · unittest

---

Autor: Yuri Oliveira Serra · [github.com/yuriserra1](https://github.com/yuriserra1)
